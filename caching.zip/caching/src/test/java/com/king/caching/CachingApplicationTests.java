package com.king.caching;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CachingApplicationTests {

	@Test
	void contextLoads() {
	}

}
